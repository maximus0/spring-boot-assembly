package hello;

/**
 * Created by chenweichao on 15-7-23.
 */
public interface GreetingService {

    void sayHello();
}
